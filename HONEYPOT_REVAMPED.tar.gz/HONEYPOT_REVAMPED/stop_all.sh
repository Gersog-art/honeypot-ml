#!/bin/bash
echo "🛑 ОСТАНОВКА HONEYPOT СИСТЕМЫ"

echo "1. Остановка honeypot..."
docker stop honeypot-juice 2>/dev/null && echo "   ✅ Honeypot остановлен" || echo "   ℹ️  Honeypot не был запущен"

echo "2. Удаление контейнера..."
docker rm honeypot-juice 2>/dev/null && echo "   ✅ Контейнер удален"

echo "3. Остановка мониторов..."
pkill -f "python.*monitor" 2>/dev/null && echo "   ✅ Мониторы остановлены" || echo "   ℹ️  Мониторы не запущены"

echo "4. Очистка временных файлов..."
rm -f logs/temp_*.log 2>/dev/null

echo ""
echo "✅ СИСТЕМА ОСТАНОВЛЕНА"
