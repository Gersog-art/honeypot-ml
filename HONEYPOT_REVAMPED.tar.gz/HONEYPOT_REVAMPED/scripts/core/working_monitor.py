#!/usr/bin/env python3
"""
РАБОЧИЙ МОНИТОР ДЛЯ HONEYPOT
Обнаруживает атаки в реальном времени без сложных зависимостей
"""

import os
import sys
import time
import json
import socket
from datetime import datetime
from threading import Thread
import subprocess

class WorkingMonitor:
    def __init__(self, port=3000):
        self.port = port
        self.stats = {
            'total': 0,
            'attacks': 0,
            'normal': 0,
            'start_time': time.time()
        }
        self.running = True
        
        # Цвета для вывода
        self.RED = '\033[91m'
        self.GREEN = '\033[92m'
        self.YELLOW = '\033[93m'
        self.BLUE = '\033[94m'
        self.CYAN = '\033[96m'
        self.RESET = '\033[0m'
        self.BOLD = '\033[1m'
        
        self.show_banner()
        
    def show_banner(self):
        """Показать баннер"""
        os.system('clear')
        print(f"{self.CYAN}{'='*70}{self.RESET}")
        print(f"{self.BOLD}{self.YELLOW}🎯 ACTIVE HONEYPOT MONITOR v1.0{self.RESET}")
        print(f"{self.CYAN}{'='*70}{self.RESET}")
        print(f"{self.GREEN}📍 Порт honeypot: {self.port}{self.RESET}")
        print(f"{self.GREEN}📡 Режим: АКТИВНОЕ ОБНАРУЖЕНИЕ{self.RESET}")
        print(f"{self.YELLOW}💡 Отправляйте запросы на http://localhost:{self.port}{self.RESET}")
        print(f"{self.CYAN}{'-'*70}{self.RESET}\n")
    
    def detect_attack(self, request_data):
        """Обнаружение атаки по правилам"""
        try:
            # Извлекаем URL из запроса
            lines = request_data.split('\n')
            if not lines:
                return {'is_attack': False, 'type': 'Normal', 'confidence': 0}
            
            # Первая строка содержит метод и URL
            first_line = lines[0]
            parts = first_line.split(' ')
            if len(parts) < 2:
                return {'is_attack': False, 'type': 'Normal', 'confidence': 0}
            
            method = parts[0]
            url = parts[1] if len(parts) > 1 else ""
            url_lower = url.lower()
            
            # Проверяем SQL инъекции
            sql_keywords = ["'", "or 1=1", "union", "--", "select ", "from ", "drop ", "insert ", "sleep(", "benchmark"]
            has_sql = any(kw in url_lower for kw in sql_keywords)
            
            # Проверяем XSS
            xss_keywords = ["<script>", "alert(", "onerror=", "onload=", "<img", "javascript:", "document.cookie"]
            has_xss = any(kw in url_lower for kw in xss_keywords)
            
            # Проверяем Path Traversal
            traversal_keywords = ["../", "..%2f", "etc/passwd", "%252f", "..\\", "../../", "%2e%2e"]
            has_traversal = any(kw in url_lower for kw in traversal_keywords)
            
            # Проверяем Command Injection
            cmd_keywords = [";", "|", "`", "$(", "&&", "||", "exec(", "system("]
            has_cmd = any(kw in url_lower for kw in cmd_keywords)
            
            # Определяем тип атаки
            attack_type = "Normal"
            confidence = 0.0
            
            if has_sql:
                attack_type = "SQL Injection"
                confidence = 0.93
            elif has_xss:
                attack_type = "XSS"
                confidence = 0.86
            elif has_traversal:
                attack_type = "Path Traversal"
                confidence = 0.78
            elif has_cmd:
                attack_type = "Command Injection"
                confidence = 0.82
            
            is_attack = has_sql or has_xss or has_traversal or has_cmd
            
            return {
                'is_attack': is_attack,
                'type': attack_type,
                'confidence': confidence,
                'method': method,
                'url': url,
                'has_sql': has_sql,
                'has_xss': has_xss,
                'has_traversal': has_traversal,
                'has_cmd': has_cmd
            }
            
        except Exception as e:
            return {'is_attack': False, 'type': f'Error: {str(e)}', 'confidence': 0}
    
    def log_attack(self, detection, src_ip, src_port):
        """Логирование атаки"""
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        print(f"\n{self.RED}{'🚨'*20}{self.RESET}")
        print(f"{self.RED}{self.BOLD}🚨 АТАКА ОБНАРУЖЕНА! [{timestamp}]{self.RESET}")
        print(f"{self.RED}{'─'*50}{self.RESET}")
        print(f"{self.YELLOW}🔥 Тип:{self.RESET} {detection['type']}")
        print(f"{self.YELLOW}📊 Уверенность:{self.RESET} {detection['confidence']:.1%}")
        print(f"{self.YELLOW}📍 Источник:{self.RESET} {src_ip}:{src_port}")
        print(f"{self.YELLOW}📝 Метод:{self.RESET} {detection['method']}")
        print(f"{self.YELLOW}🎯 URL:{self.RESET} {detection['url'][:100]}..." 
              if len(detection['url']) > 100 else f"{self.YELLOW}🎯 URL:{self.RESET} {detection['url']}")
        
        # Показываем признаки
        signs = []
        if detection['has_sql']: signs.append("SQL")
        if detection['has_xss']: signs.append("XSS")
        if detection['has_traversal']: signs.append("Traversal")
        if detection['has_cmd']: signs.append("Command")
        
        if signs:
            print(f"{self.YELLOW}🛡️  Признаки:{self.RESET} {', '.join(signs)}")
        
        print(f"{self.RED}{'─'*50}{self.RESET}")
        
        # Обновляем статистику
        self.stats['attacks'] += 1
        self.show_stats()
    
    def log_normal(self, url, src_ip, src_port, method="GET"):
        """Логирование нормального запроса"""
        self.stats['normal'] += 1
        
        # Показываем только каждый 5-й нормальный запрос
        if self.stats['normal'] % 5 == 0:
            timestamp = datetime.now().strftime("%H:%M:%S")
            print(f"{self.GREEN}[{timestamp}] 📡 {method} {src_ip}:{src_port} → {url[:50]}...{self.RESET}")
            self.show_stats()
    
    def show_stats(self):
        """Показать статистику"""
        total = self.stats['total']
        attacks = self.stats['attacks']
        normal = self.stats['normal']
        elapsed = time.time() - self.stats['start_time']
        
        if total > 0:
            print(f"\n{self.CYAN}📊 СТАТИСТИКА:{self.RESET}")
            print(f"{self.CYAN}{'─'*40}{self.RESET}")
            print(f"{self.BLUE}📦 Всего запросов:{self.RESET} {total}")
            print(f"{self.GREEN}✅ Нормальных:{self.RESET} {normal}")
            print(f"{self.RED}🚨 Атак:{self.RESET} {attacks}")
            
            if attacks > 0:
                detection_rate = attacks / total * 100
                print(f"{self.YELLOW}🎯 Эффективность:{self.RESET} {detection_rate:.1f}%")
            
            print(f"{self.YELLOW}⏱️  Время:{self.RESET} {int(elapsed)} сек")
            print(f"{self.CYAN}{'─'*40}{self.RESET}\n")
    
    def capture_traffic_tcpdump(self):
        """Захват трафика с помощью tcpdump"""
        try:
            print(f"{self.GREEN}🎯 Запуск захвата трафика на порту {self.port}...{self.RESET}")
            
            # Команда tcpdump для захвата HTTP трафика
            cmd = ['sudo', 'tcpdump', '-i', 'lo', '-A', 
                   f'port {self.port}', '-s', '0', '-l']
            
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, 
                                      stderr=subprocess.PIPE, text=True)
            
            current_request = ""
            in_http_request = False
            
            for line in iter(process.stdout.readline, ''):
                if not self.running:
                    break
                
                line = line.strip()
                
                # Ищем HTTP запросы
                if 'HTTP' in line and ('GET' in line or 'POST' in line or 'PUT' in line):
                    in_http_request = True
                    current_request = line + '\n'
                    
                    # Извлекаем IP и порт
                    src_ip = "127.0.0.1"
                    src_port = "unknown"
                    
                    # Пытаемся извлечь IP:port из строки
                    if 'IP' in line:
                        parts = line.split('IP')
                        if len(parts) > 1:
                            ip_part = parts[1].split('>')[0].strip()
                            if '.' in ip_part:
                                src_ip = ip_part.split('.')[:4]
                                src_ip = '.'.join(src_ip)
                                if ':' in ip_part:
                                    src_port = ip_part.split(':')[-1]
                    
                    self.stats['total'] += 1
                    
                    # Обнаруживаем атаку
                    detection = self.detect_attack(current_request)
                    
                    if detection['is_attack']:
                        self.log_attack(detection, src_ip, src_port)
                    else:
                        self.log_normal(detection['url'], src_ip, src_port, detection['method'])
                    
                    current_request = ""
                    in_http_request = False
                
                elif in_http_request and line:
                    current_request += line + '\n'
                    
        except KeyboardInterrupt:
            print(f"\n{self.YELLOW}🛑 Захват остановлен{self.RESET}")
        except Exception as e:
            print(f"{self.RED}❌ Ошибка захвата: {e}{self.RESET}")
    
    def start(self):
        """Запуск монитора"""
        try:
            print(f"{self.GREEN}✅ Монитор запущен!{self.RESET}")
            print(f"{self.YELLOW}📡 Ожидание трафика на порту {self.port}...{self.RESET}")
            print(f"{self.CYAN}{'-'*70}{self.RESET}\n")
            
            # Запускаем захват трафика
            self.capture_traffic_tcpdump()
            
        except KeyboardInterrupt:
            print(f"\n{self.YELLOW}🛑 Монитор остановлен{self.RESET}")
        finally:
            self.show_final_stats()
    
    def show_final_stats(self):
        """Показать финальную статистику"""
        print(f"\n{self.CYAN}{'='*60}{self.RESET}")
        print(f"{self.BOLD}📊 ФИНАЛЬНАЯ СТАТИСТИКА{self.RESET}")
        print(f"{self.CYAN}{'='*60}{self.RESET}")
        
        total_time = time.time() - self.stats['start_time']
        
        print(f"{self.BLUE}⏱️  Общее время:{self.RESET} {int(total_time)} сек")
        print(f"{self.BLUE}📦 Всего запросов:{self.RESET} {self.stats['total']}")
        print(f"{self.GREEN}✅ Нормальных:{self.RESET} {self.stats['normal']}")
        print(f"{self.RED}🚨 Атак:{self.RESET} {self.stats['attacks']}")
        
        if self.stats['total'] > 0:
            detection_rate = self.stats['attacks'] / self.stats['total'] * 100
            print(f"{self.YELLOW}🎯 Эффективность:{self.RESET} {detection_rate:.1f}%")
        
        print(f"{self.CYAN}{'='*60}{self.RESET}")

def main():
    """Точка входа"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Рабочий монитор для honeypot')
    parser.add_argument('--port', '-p', type=int, default=3000,
                       help='Порт honeypot (по умолчанию: 3000)')
    
    args = parser.parse_args()
    
    # Проверка прав
    if os.geteuid() != 0:
        print("❌ Этот скрипт требует root-прав для захвата трафика!")
        print("   Запустите: sudo python scripts/core/working_monitor.py")
        sys.exit(1)
    
    # Проверка tcpdump
    if shutil.which('tcpdump') is None:
        print("❌ tcpdump не найден в PATH!")
        print("   Проверьте установку: which tcpdump")
    	print("   Или установите: sudo apt install tcpdump")
    	sys.exit(1)
    
    monitor = WorkingMonitor(port=args.port)
    monitor.start()

if __name__ == "__main__":
    main()
